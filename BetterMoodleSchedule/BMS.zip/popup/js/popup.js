document.getElementById(`goToOptionsBtn`).addEventListener((`click`), () => chrome.runtime.openOptionsPage());
